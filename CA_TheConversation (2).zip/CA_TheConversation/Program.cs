﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA_TheConversation
{
    class Program
    {
        // *************************************************************
        // Application:     The Conversation
        // Author:          Hockin, Noah
        // Description:     A conversation about fishing
        // Date Created:    2/16/2020
        // Date Revised:    2/16/2020
        // *************************************************************

        static void Main(string[] args)
        {
            //
            // display a welcome to the user
            //
            Console.WriteLine("Greetings! Welcome to our conversation.");
            Console.WriteLine();

            //
            // begin your code
            //

            //
            // variables
            //
            string userName;
            string typeOfFishing;
            string fishingArea;
            string userResponse;
            string typeOfFish;

            int yearsFishing;
            int timesFishedPerYear;
            int averageCatch;
            int totalFishCaught;

            //
            // Opening Screen
            //
            //
            // set cursor invisible, background colors, and clear screen
            //
            Console.CursorVisible = false;
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();

            //
            // display opening screen information
            //
            Console.WriteLine();
            Console.WriteLine("\t\tThe Fisher App");
            Console.WriteLine();
            Console.WriteLine("\tPress any key to continue");
            Console.ReadKey();

            //
            // Introduction Screen
            //
            // set cursor invisible, background colors, foreground colors, and clear screen
            //
            Console.CursorVisible = true;
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();

            //
            // display header
            //
            Console.WriteLine();
            Console.WriteLine("\t\tIntroduction");
            Console.WriteLine();

            //
            // enter conversation with user
            //
            Console.WriteLine("Hello!");
            Console.WriteLine("My name is Noah.");


            //
            // get user's name
            //
            Console.WriteLine();
            Console.Write("What is your name? ");
            userName = Console.ReadLine();
            Console.WriteLine("Nice to meet you " + userName + ".");

            //
            // determine if the user like to go fishing
            //
            Console.WriteLine();
            Console.Write("Do you like to go fishing " + userName + "?");
            userResponse = Console.ReadLine();

            //
            // pause app for user
            //
            Console.WriteLine();
            Console.WriteLine("\tPress any key to continue.");
            Console.ReadKey();

            //
            // get more information if the user likes to fish
            //
            if (userResponse == "yes")
            {
                //
                // Type of fishing screen
                //
                // set cursor invisible, background colors, foreground colors, and clear screen
                Console.CursorVisible = true;
                Console.BackgroundColor = ConsoleColor.DarkBlue;
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();

                //
                // display header
                //
                Console.WriteLine();
                Console.WriteLine("\t\tType of Fishing");
                Console.WriteLine();

                //
                // get users favorite type of fishing
                //
                Console.WriteLine();
                Console.WriteLine("Awesome, I like fishing too, it's one of my favorite things to do.");
                Console.WriteLine();
                Console.WriteLine("What is your favorite type of fishing?");
                Console.Write("Do you like trolling, fly fishing, or normal fishing? ");
                typeOfFishing = Console.ReadLine();
                Console.WriteLine("So you like " + typeOfFishing + ", nice");

                //
                // get users favorite type of fish
                //
                Console.WriteLine();
                Console.Write("What kind of fish do you most like fishing for? ");
                typeOfFish = Console.ReadLine();

                //
                // get users favorite area
                //
                Console.WriteLine();
                Console.Write("Where do you like to go fishing? ");
                fishingArea = Console.ReadLine();

                //
                // provide feedback on type of fishing
                //
                Console.WriteLine();
                if (typeOfFishing == "trolling")
                {
                    Console.WriteLine("I've done a fair bit of trolling, It's quite relaxing while youre waiting but exciting when you get something.");
                    Console.WriteLine("I'll have to go to " + fishingArea + " and try trolling for " + typeOfFish + ".");
                }
                else if (typeOfFishing == "fly fishing")
                {  
                    Console.WriteLine("I haven't done much fly fishing, its a fair bit harder to do than normal fishing");
                    Console.WriteLine("Maybe if I get better at it I'll try fly fishing for " + typeOfFish + " at " + fishingArea + ".");
                }
                else if (typeOfFishing == "normal fishing")
                {
                    Console.WriteLine("I've done a lot of just regular fishing, it's simple but still a lot of fun.");
                    Console.WriteLine("I've heard that some people have done really well fishing for " + typeOfFish + " at " + fishingArea + ".");
                }
                else
                {
                    Console.WriteLine("I haven't tried that type of fishing.");
                    Console.WriteLine("You say you can catch " + typeOfFish + " there? I'll have to look into it.");
                }

                //
                // pause the app
                //
                Console.WriteLine();
                Console.WriteLine("\tPress any key to continue.");
                Console.ReadKey();

                //
                // fishing frequency screen
                //
                //set cursor invisible, background colors, foreground colors, and clear screen
                //
                Console.CursorVisible = true;
                Console.BackgroundColor = ConsoleColor.DarkBlue;
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();

                //
                // display header
                //
                Console.WriteLine();
                Console.WriteLine("\t\tAmount of Fishing");
                Console.WriteLine();

                //
                // query the user for information
                //
                Console.WriteLine("I'm curious to see about how many fish you've caught overall.");
                Console.WriteLine();

                Console.Write("How many years have you been fishing? ");
                userResponse = Console.ReadLine();
                yearsFishing = int.Parse(userResponse);
                Console.WriteLine();

                Console.Write("About how many times do you go fishing in a year? ");
                userResponse = Console.ReadLine();
                timesFishedPerYear = int.Parse(userResponse);
                Console.WriteLine();

                Console.Write("On average how many fish do you catch per trip? ");
                userResponse = Console.ReadLine();
                averageCatch = int.Parse(userResponse);
                Console.WriteLine();

                totalFishCaught = yearsFishing * timesFishedPerYear * averageCatch;

                Console.WriteLine("Well " + userName + ", based on these numbers you have caught approximately " + totalFishCaught + " fish in your lifetime.");
                Console.WriteLine("Nice!");
                Console.WriteLine();

                //
                // thank the user and say goodbye
                //
                Console.WriteLine();
                Console.WriteLine("Well " + userName + ", it was nice meeting you and I enjoyed our conversation about fishing.");
                Console.WriteLine("Have a nice day!");

                //
                // pause the app
                //
                Console.WriteLine();
                Console.WriteLine("\tPress any key to exit.");
                Console.ReadKey();
            }

            //
            // thank the user if the user is not a fisherman
            //
            else
            {
                //
                // Thank user screen
                //
                // set cursor invisible, background colors, foreground colors, and clear screen
                //
                Console.CursorVisible = true;
                Console.BackgroundColor = ConsoleColor.DarkBlue;
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();
                Console.WriteLine();
                Console.WriteLine("I am sorry you don't like fishing " + userName + ". It was nice to meet you.");

                //
                // pause the app
                //
                Console.WriteLine();
                Console.WriteLine("\tPress any key to exit");
                Console.ReadKey();
            }

            //
            // Closing screen
            //
            // set cursor invisible, background colors, foreground colors, and clear screen
            //
            Console.CursorVisible = false;
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();

            //
            // display the closing screen information
            //
            Console.WriteLine();
            Console.WriteLine("\t\tThank you for your Interest in this Application");
            Console.WriteLine();
            Console.WriteLine("\t\t\tKiller Bean Productions");
            Console.WriteLine();

            //
            // pause the app
            //
            Console.WriteLine();
            Console.WriteLine("Press any key to exit the application.");
            Console.ReadKey();
        }
    }
}
